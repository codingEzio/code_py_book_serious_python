### Libraries

- `distutils` <small>([_doc_](https://docs.python.org/3/library/distutils.html), [_tutorial_](https://docs.python.org/3/distutils/introduction.html))</small>
  1. A part of the _Python Standard Library_
  2. A better `distlib` <small>([_doc_](https://pythonhosted.org/distlib/tutorial.html), [_repo_](https://bitbucket.org/pypa/distlib/src/default/))</small> library _might_ replace it in the future.
  3. It could handle simple packaging and distribution.
- `setuptools` <small>([_doc_](https://setuptools.readthedocs.io/en/latest/setuptools.html#developer-s-guide), [_repo_](https://github.com/pypa/setuptools))</small>
  1. The **standard** for _advanced package installations_
