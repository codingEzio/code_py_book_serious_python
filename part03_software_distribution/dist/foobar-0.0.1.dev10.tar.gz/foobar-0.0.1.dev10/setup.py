import setuptools

# setuptools.setup()
setuptools.setup(
    setup_requires=['pbr'], pbr=True
)
